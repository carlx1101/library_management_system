

<?php

require "connection/connection.php";

if(isset($_POST["categorycsv"])){
		
  $filename=$_FILES["file"]["tmp_name"];		


   if($_FILES["file"]["size"] > 0)
   {
      $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
         {


           $sql = "INSERT INTO category (CategoryID, CategoryName) 
                 VALUES ('".$getData[0]."','".$getData[1]."')";
                 $result = mysqli_query($conn, $sql);
      if(!isset($result))
      {
        echo "<script type=\"text/javascript\">
            alert(\"Invalid File:Please Upload CSV File.\");
            window.location = \"admin_add_category.php\"
            </script>";		
      }
      else {
          echo "<script type=\"text/javascript\">
          alert(\"CSV File has been successfully Imported.\");
          window.location = \"admin_add_category.php\"
   

        </script>";
      }
         }
    
         fclose($file);	
   }
}	 




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>

    <?php
        require "templates/header_cdn.php" 
    ?>
<style>
    
    #toggle-show {
        display :none;
      }
</style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" ;
    ?>

    <?php

    require "connection/connection.php";

    require "admin_create_category.php";

    require "connection/close_connection.php";
    ?>


    <div class = "container">
        <form  method = "POST" >
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <h2>Add Category</h2><br>
                            <label for="categoryInput">Book Category (Genre)</label>
                            <input type="text" class="form-control" autocomplete="off" id="categoryInput" aria-describedby="categoryInput" name = "category" required>
                        </div>
                        <button type="submit"  name = "submit" class="btn btn-primary float-right" >Add</button>
                    </div>
                    <div class="col-sm-8">
                    <button class="btn btn-primary float-right"  style = "margin-right:10px;"  onclick="toggle1()" >Import (.CSV)</button>

                    <button class="btn btn-primary float-right"  style = "margin-right:10px;"  onclick="window.location.href='admin_category_csv.php'">Export (.CSV)</button>
                      </form>


                    <h2>&ensp; All Category</h2><br>
                    <?php
                    require "admin_show_category.php";
                    
                    ?>
<div id="toggle-show">
<form method ="POST" enctype="multipart/form-data">
<div class="form-group">
                            <label for="file">Category Upload CSV </label>
                            <input type="file"  class="form-control" id="file" name = "file" require>
                        </div>

  <button type="submit" class="btn btn-primary" name = "categorycsv">Submit</button>
</form>
</div>
                    </div>
                </div>
               
            </div>
            
    
        <script>
            function toggle1() {
  var x = document.getElementById("toggle-show");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
        </script>
    </div>

    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>


</body>
</html>
