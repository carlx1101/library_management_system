<?php

require "connection/connection.php";

if(isset($_POST["authorcsv"])){
		
  $filename=$_FILES["file"]["tmp_name"];		


   if($_FILES["file"]["size"] > 0)
   {
      $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
         {


           $sql = "INSERT INTO author (AuthorID, Username, Password, AuthorName, EmailAddress, PhoneNumber, bio, RegistrationDate) 
                 VALUES ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."','".$getData[7]."')";
                 $result = mysqli_query($conn, $sql);
      if(!isset($result))
      {
        echo "<script type=\"text/javascript\">
            alert(\"Invalid File:Please Upload CSV File.\");
            window.location = \"admin_all_user.php\"
            </script>";		
      }
      else {
          echo "<script type=\"text/javascript\">
          alert(\"CSV File has been successfully Imported.\");
          window.location = \"admin_all_user.php\"
        </script>";
      }
         }
    
         fclose($file);	
   }
}	 



if(isset($_POST["usercsv"])){
		
  $filename=$_FILES["file"]["tmp_name"];		


   if($_FILES["file"]["size"] > 0)
   {
      $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
         {


           $sql = "INSERT INTO user (UserID, Username, Password, Name, BioDescription, EmailAddress, Wishlist,RegistrationDate, PhoneNumber ) 
                 VALUES ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."','".$getData[7]."','".$getData[8]."')";
                 $result = mysqli_query($conn, $sql);
      if(!isset($result))
      {
        echo "<script type=\"text/javascript\">
            alert(\"Invalid File:Please Upload CSV File.\");
 
            </script>";		
      }
      else {
          echo "<script type=\"text/javascript\">
          alert(\"CSV File has been successfully Imported.\");
          window.location = \"admin_all_user.php\"
        </script>";
      }
         }
    
         fclose($file);	
   }
}	 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>

    <?php
        require "templates/header_cdn.php" 
    ?>

<style>
      .image
      {
        width:400px; 
        height:200px; 
      }

      #toggle-show {
        display :none;
      }

      #toggle-show2 {
        display :none;
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" 
    ?>
<div class = "container">
<button class="btn btn-primary float-right" onclick="toggle1()">Import (.CSV)</button>
<button class="btn btn-primary float-right"  style = "margin-right:10px;"  onclick="window.location.href='admin_author_csv.php'">Export (.CSV)</button>
      <h1>Author</h1>
   <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Author ID </th>
      <th scope="col">Username </th>
      <th scope="col">AuthorName</th>
      <th scope="col">Email Address</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Bio</th>
      <th scope="col">Registration Date</th>
      <th scope="col">Action</th>
      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";
    

    $sql = "SELECT * FROM author";  
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['AuthorID']."</td>";
        echo "<td>".$row['Username']."</td>";

        echo "<td>".$row['AuthorName']."</td>";
        echo "<td>".$row['EmailAddress']."</td>";
        echo "<td>".$row['PhoneNumber']."</td>";
        echo "<td>".$row['bio']."</td>";
        echo "<td>".$row['RegistrationDate']."</td>";
        echo "<td><a href=admin_delete_author.php?id=".$row['AuthorID']."><button type='button' class='btn btn-danger' >Remove</button></td>";   
    }
    ?>
  </tbody>
</table>

<div id="toggle-show">
<form method ="POST" enctype="multipart/form-data">
<div class="form-group">
                            <label for="file">Author Upload CSV </label>
                            <input type="file"  class="form-control" id="file" name = "file" require>
                        </div>

  <button type="submit" class="btn btn-primary" name = "authorcsv">Submit</button>
</form>
</div>

</div>









    </div>
  </div>
</div>
<br><br>
<div class = "container">
     <button class="btn btn-primary float-right" onclick="toggle2()">Import (.CSV)</button>
      <button class="btn btn-primary float-right" style = "margin-right:12px;" onclick="window.location.href='admin_reader_csv.php'">Export (.CSV)</button>
      <h1>Reader</h1>
   
   <table class="table">
  <thead>
    <tr>
      
      <th scope="col">User ID </th>
      <th scope="col">Username </th>
      <th scope="col">Reader Name</th>
      <th scope="col">Email Address</th>
      <th scope="col">Wishlist</th>
      <th scope="col">Bio</th>
      <th scope="col">Registration Date</th>
      <th scope="col">Action</th>
      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";
    

    $sql = "SELECT *  FROM user";  
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['UserID']."</td>";
        echo "<td>".$row['Username']."</td>";
        echo "<td>".$row['Name']."</td>";
        echo "<td>".$row['EmailAddress']."</td>";
        echo "<td>".$row['Wishlist']."</td>";
        echo "<td>".$row['BioDescription']."</td>";
        echo "<td>".$row['RegistrationDate']."</td>";
        echo "<td><a href=admin_delete_user.php?id=".$row['UserID']."><button type='button' class='btn btn-danger' >Remove</button></td>";   
    }
    
    ?>
  </tbody>
</table>

<div id="toggle-show2">
<form method ="POST" enctype="multipart/form-data">
<div class="form-group">
                <label for="file">User Upload CSV </label>
            <input type="file"  class="form-control" id="file" name = "file" require>
                        </div>

  <button type="submit" class="btn btn-primary" name = "usercsv">Submit</button>
</form>
</div>
</div>

<script>
function toggle1() {
  var x = document.getElementById("toggle-show");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function toggle2() {
  var x = document.getElementById("toggle-show2");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>

</body>
</html>