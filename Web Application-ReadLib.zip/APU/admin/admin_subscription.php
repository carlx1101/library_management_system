<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscription</title>

    <?php
        require "templates/header_cdn.php" 
    ?>

<style>
      .image
      {
        width:400px; 
        height:200px; 
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" 
    ?>
<div class = "container">

   <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Subscription ID</th>
      <th scope="col">User Account</th>
      <th scope="col">Email</th>


      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";
    

    $sql = "SELECT subscription.*, user.Username from subscription join user using (UserID) ";  

    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['Subscription ID']."</td>";
        echo "<td>".$row['Username']."</td>";
        echo "<td>".$row['Email']."</td>";


    }
    ?>
  </tbody>
</table>
</div>

<div class="container">
  <div class="row">
    <div class="col text-center">
      <button class="btn btn-primary" value="Print Data" onClick="window.print()">Print All</button>
      <button class="btn btn-primary" onclick="window.location.href='admin_subscription_csv.php'">Export (.CSV)</button>

    </div>
  </div>
</div>
    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>

</body>
</html>