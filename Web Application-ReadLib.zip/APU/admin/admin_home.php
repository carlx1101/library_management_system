<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Analytics</title>

    <?php
        require "templates/header_cdn.php"
    ?>
    <style>
        .QA{
            background-color: #e4ceaa;
            height: 200px;
            width: 400px;
            text-align: center;
            padding-top: 20px;
            
        }
        .p1{
            font-weight: bold;
            font-size: 36px;
            color: #ffffff;
            
        }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php";
    ?>

    <?php

    require "connection/connection.php";

    require "admin_create_category.php";


    ?>

    
    <div class="container">
        <div class="row">
            
            <div class="col-4"><p style="font-size: 50px;text-align:center;font-weight:bold">Dashboard</p></div>
            
            
        </div>
        <br><br>
        <div class="row">
            <!-- <div class="col-1"> -->

            <!-- </div> -->
            <!-- <div class="col-4 align-self-center" style="background-color: #7289da;text-align: center;height:210px;padding-top: 10px;border-radius:25px;">
                
                <br>
                <p class="p1">Quick Access</p>
                
                <a href="admin_manage_author.php" style="color: white;">
                    <button type="button" class="btn btn-warning" style="width: 300px; height:40px;color:white"> Manage Author</button>
                </a>
                
                <a href="admin_manage_book.php" style="text-decoration:none">
                    <button type="button" class="btn btn-info" style="width: 300px; height:40px;color:white">Manage Book</button>
                </a>
            </div> -->
            <!-- <div class="col-1"></div> -->
            <div class="col-md" style="height:400px;width:430px">
                <br>

                <?php 
                    require "graph01.php";
                ?>
            </div>
        <!-- </div> -->

        <!-- <div class="row"> -->
            <!-- <div class="col-1"></div> -->
            <div class="col-md" style="height:450px;width:400px" >
                <br>
                <?php 
                    require "graph02.php";
                ?>
            </div>
            <div class="col-md" >
                <br>
                <?php
                    require "graph03.php";
                ?>
        <!-- </div> -->
    </div>
    

    <?php
  
    require "templates/footer.php"
    ?>
        
    <?php
    
    require "templates/body_cdn.php"
    ?>
</body>
</html>