<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>

    <?php
        require "templates/header_cdn.php" 
    ?>

<style>
      .image
      {
        width:400px; 
        height:200px; 
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" 
    ?>
<div class = "container">

   <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Message Id</th>
      <th scope="col">Email Address</th>
      <th scope="col">Contact</th>
      <th scope="col">Messages</th>

      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";
    

    $sql = "SELECT * FROM  message";  
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['MessageID']."</td>";
        echo "<td>".$row['Email']."</td>";
        echo "<td>".$row['Contact']."</td>";
        echo "<td>".$row['Messages']."</td>";

    }
    ?>
  </tbody>
</table>
</div>

<div class="container">
  <div class="row">
    <div class="col text-center">
      <button class="btn btn-primary" value="Print Data" onClick="window.print()">Print All</button>
      <button class="btn btn-primary" onclick="window.location.href='admin_messages_csv.php'">Export (.CSV)</button>

    </div>
  </div>
</div>
    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>

</body>
</html>