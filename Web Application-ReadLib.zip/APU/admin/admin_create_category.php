<?php
    if(isset($_POST['submit']))
    {
        $bookCategory = $_POST['category'];

        $sql = "SELECT * FROM category WHERE CategoryName='$bookCategory'";
        $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));

        if(mysqli_num_rows($result) > 0) {
           echo "<script>alert('The book category is already exist')</script>";

        } else {

        $sql = "INSERT INTO category (CategoryName ) VALUES ('$bookCategory')";

        if (!mysqli_query($conn,$sql))
        {
            echo "<script>alert('Failed : Record Not Added')</script>";
        }
        else
        {
            echo "<script>alert('Record Has Been Added')
            window.location.href = 'admin_add_category.php'
            </script>";
        }
    }
  }
?>