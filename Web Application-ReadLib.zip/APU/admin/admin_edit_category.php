
<?php
require "connection/connection.php"; 

$id = $_GET['id']; 

$sql = mysqli_query($conn,"SELECT * FROM category where CategoryID='$id'"); 

$data = mysqli_fetch_array($sql); 

if(isset($_POST['update']))
{

    $categoryName = $_POST['category'];


 
    $edit = mysqli_query($conn,"UPDATE category SET CategoryName='$categoryName' WHERE CategoryID ='$id'");
	
    if($edit)
    {
        echo "<script>alert('Record Has Been Updated')
        window.location.href = 'admin_add_category.php'
        </script>";
    }
    else {
        echo "<script>alert('Updated Failed : Record Not Updated')</script>";
    }
}
$stmt = $conn->prepare("SELECT CategoryName FROM category WHERE CategoryID = '$id'");

$stmt->execute();
$stmt->bind_result($BookCategory);
$stmt->fetch();
$stmt->close();

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>

    <?php
        require "templates/header_cdn.php" 
    ?>

</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" ;
    ?>

  


    <div class = "container">
        <form  method = "POST" >
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <h2>Edit Category</h2><br>
                            <label for="categoryInput">Book Category (Genre)</label>
                            <input type="text" class="form-control" autocomplete="off" id="categoryInput" aria-describedby="categoryInput" name = "category" value = "<?=$BookCategory?>" required>
                        </div>
                        <button type="submit"  name = "update" class="btn btn-primary float-right" >Add</button>
                    </div>

                </div>
            </div>
        </form>
    </div>

    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>


</body>
</html>

