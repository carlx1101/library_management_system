<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0 "></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>
<div class="container" style="height:400px;width:450px;">
        <canvas id="mychart03" style="background-color:#79B4B7;box-shadow: 0 15px 30px 0 rgba(0,0,0,0.11),0 5px 15px 0 rgba(0,0,0,0.08);border-radius:12px;"></canvas>
    </div>

    <?php
        require"connection/connection.php";

        $sql=sprintf("SELECT COUNT(book.BookID),category.CategoryName from book INNER JOIN category WHERE book.CategoryID=category.CategoryID GROUP BY book.CategoryID");
        $records=mysqli_query($conn,$sql);

        foreach($records as $row){
            $row01=$row["CategoryName"];
            $bookcat[]=$row01;
            $row02=$row["COUNT(book.BookID)"];
            $bookdata[]=$row02;

        }
    ?>

    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0 "></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-datalabels/2.0.0-rc.1/chartjs-plugin-datalabels.min.js" integrity="sha512-+UYTD5L/bU1sgAfWA0ELK5RlQ811q8wZIocqI7+K0Lhh8yVdIoAMEs96wJAIbgFvzynPm36ZCXtkydxu1cs27w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        const bookcatdata=<?php echo json_encode($bookcat);?>;
        const bookdata=<?php echo json_encode($bookdata);?>;

        //randomcolor for background
        var randomColorGenerator = function () { 
            return '#' + (Math.random().toString(16) + '0000000').slice(2, 8); 
        };

        function poolColors(a) {
            var pool = [];
            for(i = 0; i < a; i++) {
                pool.push(randomColorGenerator());
            }
            return pool;
        }
        var chart01= document.getElementById('mychart03').getContext('2d')

        var chart02=new Chart(chart01,{
            type:'pie',
            data:{
                labels:bookcatdata,
                
                datasets:[{
                    color:'White',
                    label:"1234",
                    data:bookdata,
                    backgroundColor:poolColors(bookcatdata.length),
                    hooverBorderWidth:1,
                    hoverBorderColor:'#EA6227'
                }]
            },
            options:{
                tooltips:{
                    enabled:true
                },
                responsive:true,
                radius:'90%',
                plugins:{
                    title:{
                        display:true,
                        text:'Book Data',
                        font:{size:20},
                        color:'white'
                    },
                    legend:{
                        position:"right",
                        title:{
                            display:true,
                            text:"Book Category",
                            color:'white',
                            font:{
                                weight:'bold',
                                
                            }
                        },
                        labels:{
                            color:'white'
                        }
                    },
                    datalabels:{
                        color:'white',
                        font:{
                            weight:'bold',
                            size:15
                        }
                    }
                    
                    
                }
            },
            plugins:[ChartDataLabels],
            
        })
    </script>
</body>
</html>