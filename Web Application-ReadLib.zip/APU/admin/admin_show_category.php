
<div class = "container text-center">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Category Number</th>
      <th scope="col">Category Name</th>
      <th scope="col">Modification</th>
      <th scope="col">Delete</th>

      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";

    $sql = "SELECT * FROM category";  
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['CategoryID']."</td>";
        echo "<td>".$row['CategoryName']."</td>";
        echo "<td><a href=admin_edit_category.php?id=".$row['CategoryID']."><button type='button' class='btn btn-warning' >Edit</button></td>";   
        echo "<td><a href=admin_delete_category.php?id=".$row['CategoryID']."><button type='button' class='btn btn-danger' >Delete</button></td>"; 
    }
?>
    
  </tbody>
</table>
</div>
