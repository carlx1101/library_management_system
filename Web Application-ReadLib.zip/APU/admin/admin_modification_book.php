<?php

require "connection/connection.php";

if(isset($_POST["authorcsv"])){
		
  $filename=$_FILES["file"]["tmp_name"];		


   if($_FILES["file"]["size"] > 0)
   {
      $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
         {


           $sql = "INSERT INTO book (BookID, SerialNumber, BookTitle, BookDescription, PublisherName, ResourceUrl, PublishedDate, ImageCover) 
                 VALUES ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."','".$getData[7]."')";
                 $result = mysqli_query($conn, $sql);
      if(!isset($result))
      {
        echo "<script type=\"text/javascript\">
            alert(\"Invalid File:Please Upload CSV File.\");
            window.location = \"admin_all_user.php\"
            </script>";		
      }
      else {
          echo "<script type=\"text/javascript\">
          alert(\"CSV File has been successfully Imported.\");
          window.location = \"admin_all_user.php\"
        </script>";
      }
         }
    
         fclose($file);	
   }
}	 



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Books</title>

    <?php
        require "templates/header_cdn.php" 
    ?>

<style>
      .image
      {
        width:300px; 
        height:200px; 
      }

      
      #toggle-show {
        display :none;
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_admin_header.php" 
    ?>
<div class = "container">


    <button class="btn btn-primary float-right " style = "margin-right:12px;" onclick="window.location.href='admin_book_csv.php'">Export (.CSV)</button>

<h1>Books</h1>

   <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Book Title</th>
      <th scope="col">Serial Number</th>
      <th scope="col">Book Description</th>
      <th scope="col">Book Category</th>
      <th scope="col">Publisher Name</th>
      <th scope="col">Publisher Date</th>
      <th scope="col">Digital Sources</th>
      <th scope="col">Cover Image</th>
      <th scope="col">AuthorName</th>
      <th scope="col">Remove</th>

      
    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";
    

    $sql = "SELECT book.*, category.CategoryName ,author.AuthorName FROM book JOIN category USING (CategoryID) JOIN author USING (AuthorID) ";  
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['BookTitle']."</td>";
        echo "<td>".$row['SerialNumber']."</td>";
        echo "<td>".$row['BookDescription']."</td>";
        echo "<td>".$row['CategoryName']."</td>";
        echo "<td>".$row['PublisherName']."</td>";
        echo "<td>".$row['PublishedDate']."</td>";
        echo "<td>".$row['ResourceUrl']."</td>";
        echo '<td><img class = "image" src="data:image/png;base64,'.base64_encode($row['ImageCover']).'"/>'. '</td>';
        echo "<td>".$row['AuthorName']."</td>";
        echo "<td><a href=delete_book.php?id=".$row['BookID']."><button type='button' class='btn btn-danger' >Remove</button></td>";   
    }
    ?>
    
  </tbody>
</table>
<div id="toggle-show">
<form method ="POST" enctype="multipart/form-data">
<div class="form-group">
                <label for="file">Book Upload CSV </label>
            <input type="file"  class="form-control" id="file" name = "file" require>
                        </div>

  <button type="submit" class="btn btn-primary" name = "usercsv">Submit</button>
</form>
</div>
</div>
<script>
            function toggle1() {
  var x = document.getElementById("toggle-show");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
        </script>

    <?php
        require "templates/footer.php" 
    ?>
    
    <?php
        require "templates/body_cdn.php" 
    ?>

</body>
</html>