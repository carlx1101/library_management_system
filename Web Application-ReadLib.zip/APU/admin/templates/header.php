
    <style>
          @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
          font-size: 31px !important;
          font-family:montserrat;
          font-weight: bold;
      }

      .navbar{
          height: 220px;
          padding-top: -50px;

      }

      .description{
          color: rgb(155, 153, 153);
      }

      .btn{
          margin-top: 5px;
      }

      .navbar-nav{
          font-weight: bold;
      }
      
      h1{
        font-weight: bold;
      }
      
      p{
        line-height: 31px;
      }
    </style>

    
<!-- User Navigation Start--> 
<nav class="navbar container navbar-expand-lg navbar-light">
      <a class="navbar-brand" href="#">ReadLib</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item active">
            <a class="nav-link"  href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Library</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Profile</a>
          </li>
          <li class="nav-item">
            <button type="button" class="btn btn-danger  btn-sm rounded-pill" style="width: 90px; height: 28px;">Logout</button>
          </li>
        </ul>
      </div>
    </nav>

