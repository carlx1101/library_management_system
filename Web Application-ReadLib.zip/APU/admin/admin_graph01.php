<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.1/dist/chart.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>
    <div class="container">
        <canvas id="mychart01" style="background-color:#FEE440;box-shadow: 0 15px 30px 0 rgba(0,0,0,0.11),0 5px 15px 0 rgba(0,0,0,0.08);border-radius:12px;"></canvas>
    </div>

    <?php
    require "connection/connection.php";
        
        $query=sprintf("SELECT COUNT(UserID),MONTHNAME(RegistrationDate) From user GROUP BY MONTHNAME(RegistrationDate) ORDER BY MONTH(RegistrationDate) DESC");
        $records=mysqli_query($conn,$query);
        
        $userdata=array();
        foreach($records as $row){
            $row=$row["COUNT(UserID)"];
            $userdata[]=$row;
        }
        
        $query02=sprintf("SELECT COUNT(AuthorID), MONTHNAME(RegistrationDate) FROM author GROUP BY MONTHNAME(RegistrationDate) ORDER BY MONTH(RegistrationDate) DESC");
        $records02=mysqli_query($conn,$query02);
        $authordata=array();
        foreach($records02 as $row){
            $row01=$row["COUNT(AuthorID)"];
            $authordata[]=$row01;
            $row02=$row["MONTHNAME(RegistrationDate)"];
            $monthdata[]=$row02;
        }
    ?>

    <?php
        print_r($userdata);
        echo "<br>";
        print_r($authordata);
        echo "<br>";
        print_r($monthdata)

    ?>

    
    <script>
        const data01=<?php echo json_encode($userdata);?>;
        const data02=<?php echo json_encode($authordata);?>;
        const month01=<?php echo json_encode($monthdata);?>;
        var chart01= document.getElementById('mychart01').getContext("2d");
        
        
        
        var chart02= new Chart(chart01, {
            type:'line',
            data:{
                labels:month01,
                datasets:[
                    {
                        label:'New Users',
                        data:data01,
                        backgroundColor:'#7289da',
                        borderColor:'#7289da'
                    },
                    {
                        label:'New Authors',
                        data:data02,
                        backgroundColor:'red',
                        borderColor:'red'
                    }
                ]
            },
            options:{
                scales:{
                    y:{
                        beginAtZero:true,
                        max:10,
                        grid:{
                            color:'white',
                            borderColor:'white'
                        },
                        ticks:{
                            color: "white",
                            stepSize:2,
                            
                            
                        },
                    },
                    x:{
                        ticks:{
                            color:'white'
                        },
                        grid:{
                            color:'white'
                        }
                    }

                },
                plugins:{
                    title:{
                        display:true,
                        text:'Recent Number Of New Users',
                        font:{size:30},
                        color:'white'
                    },
                    legend:{
                        labels:{
                            color:'white'
                        },
                        title:{
                            color:'white'
                        }
                    },

                }
                
            }
        });

    </script>
</body>
</html>