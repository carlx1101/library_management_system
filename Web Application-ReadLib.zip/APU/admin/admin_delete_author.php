
<?php
    require "connection/connection.php";
    $sql = "DELETE FROM author WHERE AuthorID ='$_GET[id]'";

    
    if (!mysqli_query($conn,$sql))
    {
        echo "<script>alert('Failed : Record Not Deleted')</script>";
    }
    else
    {   

        echo "<script>alert('Record Has Been Deleted')
        window.location.href = 'admin_all_user.php'
        </script>";
    }
?>
