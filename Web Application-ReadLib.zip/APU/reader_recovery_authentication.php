<?php
        session_start();
        require "main/connection/connection.php";


        if ($stmt = $conn->prepare('SELECT UserID, EmailAddress FROM user WHERE Username = ?')) {
            $stmt->bind_param('s', $_POST['username']);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($userID, $email);
                $stmt->fetch();

                if ($_POST['email'] === $email) {
                    session_regenerate_id();
                    $_SESSION['authenticated'] = TRUE;
                    $_SESSION['username'] = $_POST['username'];
                    $_SESSION['UserID'] = $userID;

                    echo "<script>alert('You have succesfully found your account!')
                    window.location.href = 'reader_account_info.php'
                    </script>";

                } else {
                    echo "<script>alert('Incorret Username or Email')
                    window.location.href = 'reader_account_recovery.php'
                    </script>";
                }
            } else {
                echo "<script>alert('Incorret Username or Email')
                window.location.href = 'reader_account_recovery.php'
                </script>";
            }
            $stmt->close();
        }
        ?>
