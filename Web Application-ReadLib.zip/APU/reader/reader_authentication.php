<?php
        session_start();
        require "connection/connection.php";


        if ($stmt = $conn->prepare('SELECT UserID, Password FROM user WHERE Username = ?')) {
            // Bind parameters (s = string, i = int, b = blob, etc)
            $stmt->bind_param('s', $_POST['username']);
            $stmt->execute();

            // Store the result so we can check if the account exists in the database.
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($userID, $password);
                $stmt->fetch();

                if (md5($_POST['password']) === $password) {
                    // Verification  success! User has logged-in!
                    // Create sessions, so we know the user is logged in, they basically act like cookies but remember the data on the server.
                    
                    session_regenerate_id();
                    $_SESSION['authenticated'] = TRUE;
                    $_SESSION['username'] = $_POST['username'];
                    $_SESSION['UserID'] = $userID;

                    echo "<script>alert('Login Success !')
                    window.location.href = 'reader_home.php'
                    </script>";

                } else {
                    // Incorrect password
                    echo "<script>alert('Incorret Username or Password')
                    window.location.href = 'reader_login.php'
                    </script>";
                }
            } else {
                // Incorrect username
                echo "<script>alert('Incorret Username or Password')
                window.location.href = 'reader_login.php'
                </script>";
            }
            $stmt->close();
        }
        ?>
