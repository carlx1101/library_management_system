<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
        require "templates/header_cdn.php"
    ?>

    <title>User Login</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
          font-size: 31px !important ;
          font-family:montserrat;
          font-weight: bold;
      }

      .navbar{
          height: 90px;
      }

      .description{
          color: rgb(155, 153, 153);
      }

      #button-register{
          float: right;
      }

      body {
            opacity: 0;
            transition: opacity 3s;
        }
    </style>
  </head>
  <body onload="document.body.style.opacity='1'">

    <!-- Navigation Bar Start-->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class=" navbar-brand h1" href="../index.php" >ReadLib</a>
        </div>
    </nav>
    <!-- Navigation Bar End-->

    <!-- 2 Columns 1 Row Seperator Start-->
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
        <div class="row">
          <div class="col-sm-5">
            <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="images/carousel_image.jpg" class="d-block w-100" alt="Carousel Image">
        </div>
        <div class="carousel-item">
        <img src="images/carousel_image_third.jpg" class="d-block w-100" alt="Carousel Image">
        </div>
    </div>
    </div>
</div>

    <!-- Bootstrap Carousel Slider End-->
    <div class="col-sm-1">
    </div>
    <!-- Bootstrap User Registration Form Start-->

          <div class="col-sm-6">
            <form method="POST" action = "reader_authentication.php">
                <h1>Login</h1>
                <p class= "description">Writing is an art and a craft that needs to be developed through deliberate practice and study over a long period of time.

</p>
                <div class="mb-3">
                  <label for="username" class="form-label">Username</label>
                  <input type="text" class="form-control rounded-pill" id ="username" aria-describedby="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" class="form-control rounded-pill" name="password" maxlength="12"  required>
                </div>

                  <br>
                
                <a href="reader_registration.php" style = "height:100px; line-height:60px; margin-left :320px;">Sign Up</a>
                <button type="submit" class="btn btn-primary btn-lg rounded-pill" id="button-register" style=" padding: 10px 10px;
                font-size: 20px;
                border-radius: 10px;
                width:30%;">Login</button>
              </form>

          </div>
        </div>
      </div>
    <!-- Bootstrap User Registration Form End-->
    <!-- 2 Columns 1 Row Seperator End-->
    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>

  </body>
</html>
