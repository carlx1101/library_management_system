
<?php
require "authentication/session_authentication.php";
require "connection/connection.php";

$emailSub = $_POST['subscription'];
$userID = $_SESSION['UserID'];
$sql = "INSERT INTO subscription (Email, UserID ) VALUES ('$emailSub','$userID')";

if (mysqli_query($conn,$sql))
{
    echo "<script>alert('Success : Email Address Subscribed ')
    window.location.href = 'reader_home.php'
    </script>";
}
else
{
    echo "<script>alert('Failed: Email Address Not Subscribed !')

    </script>";
}

?>