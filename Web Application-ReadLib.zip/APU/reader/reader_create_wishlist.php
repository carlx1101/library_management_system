<?php
session_start();
require "connection/connection.php";
if(!isset($_SESSION['UserID'])) {

} 
else 
{
  $uid = $_SESSION['UserID'];
  $bid = $_GET['id'];

  $sql = "SELECT * FROM wishlist WHERE BookID = $bid AND UserID = $uid";
  $result_check = mysqli_query($conn, $sql);

  if(mysqli_num_rows($result_check) == 1) 
  {
    echo "<script>alert('Book already added into wishlist')
    window.location.href = 'reader_library.php'
    </script>";


  } 
  else 
  {

    $sql = "INSERT INTO wishlist (UserID, BookID) VALUES ('$uid', '$bid')";

    if(mysqli_query($conn, $sql)) {
      echo "<script>alert('You have successfully added into wishlist')
      window.location.href = 'reader_library.php'
      </script>";
    }
  }
}