<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['authenticated'])) {
	header('Location: reader_login.php');
	exit;
}

require "connection/connection.php";
// We don't have the password or email info stored in sessions so instead we can get the results from the database.
$stmt = $conn->prepare('SELECT Username, Password, Name, BioDescription, EmailAddress, COUNT(Wishlist), RegistrationDate, PhoneNumber FROM user WHERE UserID = ?');

$stmt->bind_param('i', $_SESSION['UserID']);
$stmt->execute();
$stmt->bind_result($username, $password, $name, $bio, $emailAddress, $wishlist, $registrationDate, $phoneNumber);
$stmt->fetch();
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@<?=$_SESSION['username']?></title>
    <?php
    require "templates/header_cdn.php"
    ?>

<style>  
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
          font-size: 31px !important;
          font-family:montserrat;
          font-weight: bold;
      }

      .navbar{
          height: 220px;
          padding-top: -50px;

      }

      .description{
          color: rgb(155, 153, 153);
      }

      .btn{
          margin-top: 5px;
      }

      .navbar-nav{
          font-weight: bold;
      }
      
      h1{
        font-weight: bold;
      }
      p{
        line-height: 31px;
      }

      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
          
        }
      }

      .form-control {
        width: 490px !important;
        height: 40px;
      }

      .map-container{
      overflow:hidden;
      padding-bottom:56.25%;
      position:relative;
      height:0;
      }
      .map-container iframe{
      left:0;
      top:0;
      height:100%;
      width:100%;
      position:absolute;
      }

      .jumbotron{
        opacity: 0.8;
      }
      
      .second-nav{
        padding-bottom:210px !important;


      }

      ion-icon {
      font-size: 20px;
      color: #68A5FE;
      }

      body {
  padding: 25px;
  background-color: white;
  color: black;

}

.dark-mode {
  background-color: yellow;
  color: white;
}
    </style>
</head>
<body>
<?php
    require "templates/authenticated_user_header.php"
    ?>
<nav>
    <div class="container">
    

    <div class="d-flex align-items-start">
  <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">User Information</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Privacy & Security</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-data" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Backup & Data</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-custom" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Personalization</button>

  </div>
  <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
      
<div class="container" style="margin-left:130px;">
    <p><b>Username : </b>@<?=$_SESSION['username']?> </p>
    <p><b>Bio :</b> <?=$bio?></p>
    <p><b>Full Name :</b> <?=$name?></p>
    <p><b>Email Address :</b> <?=$emailAddress?></p>
    <p><b>Phone Number :</b> <?=$phoneNumber?></p>
    <p><b>Number of Wishlist:</b> <?=$wishlist?></p>
    <p><b>Registration Date : </b><?=$registrationDate?></p>



    <button type="button" class="btn btn-primary" onclick="window.location.href='reader_edit_info.php?id=<?=$_SESSION['UserID']?>'" style="width:110px;">Edit</button>
    </div>

    </div>
    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">

    <br><br><p><b> Account Username : </b><?=$_SESSION['username']?></p>
    <p><b>Account Password  (Encrypted):</b> <?=$password?></p>

    <button type="button" class="btn btn-primary" onclick="window.location.href='reader_edit_credential.php?id=<?=$_SESSION['UserID']?>'" style="width:110px;">Edit</button>
    </div>

    </div>

    <div class="tab-pane fade" id="v-pills-data" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">
    
    <p><b> Account Information </b> <a href="profile_csv.php?id=<?=$_SESSION['UserID']?>">Download</a></p>

    </div>
    </div>
    
    <div class="tab-pane fade" id="v-pills-custom" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">
    <button type="button" class="btn btn-dark" onclick="darkmd()" style="width:110px;">Dark Mode</button>


      <script>function darkmd() 
      {
      var element = document.body;
      element.classList.toggle("dark-mode");
    }
    </script>

    </div>
    </div>
  </div>
</div>
    </div>


    <?php
        require "templates/footer.php"
    ?>
    <?php
        require "templates/body_cdn.php"
    ?>
</body>
</html>

