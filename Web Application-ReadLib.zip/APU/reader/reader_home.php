<?php
require "authentication/session_authentication.php";
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php
    require "templates/header_cdn.php"
    ?>
    <title>Home</title>

  <style>
    .jumbotron
    {
      background-color:#f0f0f0;
    }
  </style>
  </head>

  <body>
  <?php

  require "templates/authenticated_user_header.php"
  ?>

    <!-- 2 Columns 1 Row Seperator Start-->
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
      <div class="row">
        <div class="col-sm-5">
          <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
      <div class="carousel-item active">
      <img src="images/carousel_image.jpg" class="d-block w-100" alt="Carousel Image">
      </div>
  </div>
  </div>
</div>

  <!-- Bootstrap Carousel Slider End-->
  <div class="col-sm-1">
  </div>
  <!-- Bootstrap User Registration Form Start-->

        <div class="col-sm-6">
              <h1>Welcome @<?=$_SESSION['username']?></h1><br>
              <p>ReadLib is an online public library portal that offers free and open-source publications. Beautiful and user-friendly web experience that makes reading and publications enjoyable! We deliver the best e-book service in the world, without regard to time or location. We hope you have a pleasant experience while using the services! </p>
              <div class="d-grid col-6" style="margin-left:-25px;">
                <button class="btn btn-primary rounded-pill" style="font-size: large;" type="button" onclick="window.location.href='reader_library.php'" > Library</button>
              </div>
        </div>
      </div>
    </div>

  <!-- Bootstrap User Registration Form End-->
  <!-- 2 Columns 1 Row Seperator End-->
  <br><br><br><br>

    <div class="container" style="text-align: center;" >
    <h1>Notability</h1><br>
    <p>We strive to deliver the finest experience and services for our valued customers, thus below are some of the system's features.</p>
    </div>
    <div class="container px-1 py-5" id="custom-cards">
        <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-5 py-3">
          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/card.gif);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-10 lh-1.5 fw-bold">Any Where, Any Time</h2>
              </div>
            </div>
          </div>

          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/carousel_image_third.jpg);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-8 lh-1.5 fw-bold">Every Publication You Need</h2>
              </div>
            </div>
          </div>

          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/card2.jpg);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-8 lh-1.5 fw-bold">Every Moment You Feel </h2>
              </div>
            </div>
          </div>
  </div>
    <br><br><br><br><br><br>

    <!-- 2 Columns 1 Row Seperator Start-->
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <h1>Author's Publication</h1><br>
          <p>Writing is an art and a craft that needs to be developed through deliberate practice and study over a long period of time.</p>
          <div class="d-grid col-6" style="margin-left:-25px;">
            <button class="btn btn-primary rounded-pill" style="font-size: large;" type="button" onclick="window.location.href='../author/author_registration.php'" >Publish</button>
          </div>
    </div>
  <!-- Bootstrap Carousel Slider End-->
  <div class="col-sm-1">
  </div>
  <!-- Bootstrap User Registration Form Start-->

  <div class="col-sm-5">
    <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<img src="images/feature.gif" class="d-block w-100" alt="Carousel Image">
</div>
</div>
</div>
</div>
</div>
</div>
  <!-- Bootstrap User Registration Form End-->
  <!-- 2 Columns 1 Row Seperator End-->
<br><br>
    <br><br><br><br>
    <div class="jumbotron text-center">
      <div class="container">
        <h1>Newsletter Subscription </h1><br>
        <p>By subscribing to our newsletter, you will receive monthly updates on the newest news and specials, as well as information on all of the system's features and functions.</p>
        <form method = "POST" action = "reader_subscription.php">
          <div class="form-group form-inline justify-content-center">
            <input type="email" class="form-control rounded-pill " id="Subscription" aria-describedby="emailHelp" placeholder="Enter email" name = "subscription">
            &emsp;<button type="submit" class="btn btn-primary rounded-pill" >Submit</button>
          </div>
        </form>
      </div>
    </div> <br><br><br><br><br>

    <div class="container">
  <div class="row">
    <div class="col-sm">
<!--Google map-->
  <div id="map-container-google-1" class="z-depth-1-half map-container" style="height: 500px">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.711102342523!2d101.70916861475737!3d3.1705761976914335!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc363cb072216b%3A0x65873743f9f1c478!2sNational%20Library%20of%20Malaysia!5e0!3m2!1sen!2smy!4v1633328981570!5m2!1sen!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
<!--Google Maps-->

  </div>
    <div class="col-sm">
      <h1>Contact Us </h1><br>
      <p>By subscribing to our newsletter, you will receive monthly updates on the newest news and specials, as well as information on all of the system's features and functions.</p>
      <form method = "POST" action = "reader_contact.php">
        <div class="form-group">
          <label for="email">Email address</label>
          <input type="email" class="form-control rounded-pill " id="email" aria-describedby="emailHelp" placeholder="Enter email" name = "email">
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>

        <div class="form-group">
          <label for="contact">Contact Number</label>
          <input type="tel" class="form-control rounded-pill" id="contact" placeholder="Phone" name = "contact">
        </div>

        <div class="form-group">
          <label for="message">Message</label>
          <textarea class="form-control" id="message" rows="3" name = "messages"></textarea>
        </div>
        <button class="btn btn-primary rounded-pill float-right" style="font-size: large;" type="submit">Submit</button>
      </form>
    </div>
  </div>
</div>
<!-- Appy Chatbot widget, Paste the code in the <body> section -->
<script id="appyWidgetInit" src="https://chatbot.appypie.com/widget/loadbuild.js?cid=kkhm5un7-AGENT1611884078179-BOTID1635734226912&amp;name=mixBuild"></script>
<!-- /. End Appy chatbot widget code -->
  <?php

  require "templates/footer.php"
  ?>

  <?php
  require "templates/body_cdn.php"
  ?>

  </body>
</html>
