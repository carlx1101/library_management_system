<?php
require "connection/connection.php";

$id = $_GET['id'];

if(isset($_POST['update']))
{
    $id = $_GET['id'];
    $bio = $_POST['bio'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phoneNumber = $_POST['tel'];

    $edit = mysqli_query($conn,"UPDATE user SET BioDescription ='$bio', Name = '$name', EmailAddress = '$email' , PhoneNumber = '$phoneNumber' WHERE UserID ='$id'");
   
    if($edit)
    {
        echo "<script>alert('Record Has Been Updated')
        window.location.href = 'reader_profile.php'
        </script>";
    }
    
    else {
        echo "<script>alert('Updated Failed : Record Not Updated')</script>";
    }
}
$stmt = $conn->prepare("SELECT Name, EmailAddress, BioDescription, PhoneNumber  FROM user WHERE UserID = '$id'");

$stmt->execute();
$stmt->bind_result($readerName, $emailAddress, $bio, $phoneNumber);
$stmt->fetch();
$stmt->close();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Details</title>

    <?php
        require "templates/header_cdn.php"
    ?>

</head>
<body>

    <?php
        require "templates/authenticated_user_header.php"

    ?>




<div class="container">
<form method = "POST" >

  <div class="row">
    <div class="col">
  
  <div class="mb-3">
    <label for="bio" class="form-label">Bio Description</label>
    <input type="text" class="form-control" id="bio" aria-describedby="bio" name= "bio" value = "<?=$bio?>">  
  </div>

  <div class="mb-3">
    <label for="name" class="form-label">Full Name</label>
    <input type="text" class="form-control" id="name" name = "name"  value = "<?=$readerName?>" >  
  </div>


  
    </div>
    <div class="col">

      <div class="mb-3">
    <label for="email" class="form-label">Email Address</label>
    <input type="email" class="form-control" id="email" name = "email" value = "<?=$emailAddress?>">
  </div>
    <div class="mb-3">
    <label for="tel" class="form-label">Phone Number</label>
    <input type="tel" class="form-control" id="tel" name = "tel" value = "<?=$phoneNumber?>">
  </div>


  <br><br>
    <button type="submit" name = "update" class="btn btn-primary float-right">Submit</button>
    
    </form>
    </div>
  </div>
</div>

<div class="container">

</div>
    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>
</body>
</html>