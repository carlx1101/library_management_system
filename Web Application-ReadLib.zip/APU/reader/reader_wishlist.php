<?php
require "authentication/session_authentication.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>

    <?php
        require "templates/header_cdn.php"
    ?>

<style>
      .image
      {
        width:170px;
        height:200px;
      }
      h1{
        text-align: center;
        padding-bottom: 20px;
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_user_header.php"
    ?>
<div class = "container">
   <h1>My Wishlist</h1>

   <table class="table">
  <thead>
    <tr>

      <th scope="col">Book Image</th>
      <th scope="col">Book Title</th>
      <th scope="col">Book Description</th>
      <th scioe="col">Remove</th>

    </tr>
  </thead>
  <tbody>
  <?php


    require "connection/connection.php";

    $uid = $_SESSION['UserID'];
    $sql = "SELECT * from wishlist JOIN book on book.BookID = wishlist.BookID WHERE UserID = '$uid'";
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo '<td><img class = "image" src="data:image/png;base64,'.base64_encode($row['ImageCover']).'"/>'. '</td>';
        echo "<td><a href=reader_book_review.php?id=".$row['BookID'].">".$row['BookTitle']."</td>";
        echo "<td>".$row['BookDescription']."</td>";
        echo "<td><a href=reader_delete_wishlist.php?id=".$row['BookID']."><button type='button' class='btn btn-danger' >Remove</button></td>";
    }
    ?>
  </tbody>
</table>
</div>

<div class="container">
  <div class="row">
    <div class="col text-center">
      <button class="btn btn-primary" value="Print Data" onClick="window.print()">Print All</button>
      <button class="btn btn-primary" value="Print Data" onclick = window.location.href='reader_library.php'>Return</button>
    </div>
  </div>
</div>
    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>

</body>
</html>
