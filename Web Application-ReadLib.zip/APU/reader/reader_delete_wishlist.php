<?php

   session_start();
   require "connection/connection.php";

    $uid = $_SESSION['UserID'];
    $sql = "DELETE FROM wishlist WHERE UserID = '$uid' AND BookID ='$_GET[id]'";

    if (!mysqli_query($conn,$sql))
    {
        echo "<script>alert('Failed : Record Not Deleted')</script>";
    }
    else
    {
        echo "<script>alert('Record Has Been Deleted')
        window.location.href = 'reader_wishlist.php'
        </script>";
    }
?>
