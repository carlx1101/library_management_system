
<?php
require "authentication/session_authentication.php";
require "connection/connection.php";

$email = $_POST['email'];
$contact = $_POST['contact'];
$messages = $_POST['messages'];

$sql = "INSERT INTO message (Email, Contact, Messages ) VALUES ('$email','$contact','$messages')";

if (mysqli_query($conn,$sql))
{
    echo "<script>alert('Success : Message Has Been Sent ')
    window.location.href = 'reader_home.php'
    </script>";
}
else
{
    echo "<script>alert('Failed: Message Not Sent !')

    </script>";
}

?>