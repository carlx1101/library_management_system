<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Information</title>

    <?php
        require "main/templates/header_cdn.php"
    ?>

<style>
      .image
      {
        width:170px;
        height:200px;
      }
      h1{
        text-align: center;
        padding-bottom: 20px;
        padding-top: 100px;
      }
      .content{
        padding-left:420px;
        padding-right:420px;
      }
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
        font-size: 31px !important;
        font-family:montserrat;
        font-weight: bold;
      }
      button{
        margin-bottom: 100px;
      }
    </style>
</head>
<body>
<nav class="navbar container navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="../index.php">ReadLib</a>
</nav>

<div class = "container">
   <h1>Your Personal Account</h1>
   <div class = "content">
   <hr>
    <?php
    session_start();

    require "main/connection/connection.php";

    $uid = $_SESSION['UserID'];
    $sql = "SELECT * from user WHERE UserID = '$uid'";
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<h6>Username: ".$row['Username']."</h6>"."<br>";
        echo "<h6>Password: ".$row['Password']."</h6>"."<br>";
        echo "<h6>Email Address: ".$row['EmailAddress']."</h6>";
    }
    ?>
    <hr>
    </div>
</div><br><br>
<iframe src="https://md5decrypt.net/en/" frameborder="0" width = "1000px" height = "500" style = "margin-left:450px;">


</iframe>
<br><br>
<div class="container">
  <div class="row">
    <div class="col text-center">
      <button class="btn btn-primary"  onclick = window.location.href='../APU/index.php'>Return to Dashboard</button>
    </div>
  </div>
</div>


    <?php
        require "main/templates/body_cdn.php"
    ?>

</body>
</html>
