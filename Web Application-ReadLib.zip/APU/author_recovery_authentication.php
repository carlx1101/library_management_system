<?php
        session_start();
        require "main/connection/connection.php";


        if ($stmt = $conn->prepare('SELECT AuthorID, EmailAddress FROM author WHERE Username = ?')) {
            $stmt->bind_param('s', $_POST['username']);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($authorID, $email);
                $stmt->fetch();

                if ($_POST['email'] === $email) {
                    session_regenerate_id();
                    $_SESSION['authenticated'] = TRUE;
                    $_SESSION['username'] = $_POST['username'];
                    $_SESSION['AuthorID'] = $authorID;

                    echo "<script>alert('You have succesfully found your account!')
                    window.location.href = 'author_account_info.php'
                    </script>";

                } else {
                    echo "<script>alert('Incorret Username or Email')
                    window.location.href = 'author_account_recovery.php'
                    </script>";
                }
            } else {
                echo "<script>alert('Incorret Username or Email')
                window.location.href = 'author_account_recovery.php'
                </script>";
            }
            $stmt->close();
        }
        ?>
