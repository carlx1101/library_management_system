<?php
require "authentication/session_authentication.php";
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://kit.fontawesome.com/378db2667c.js" crossorigin="anonymous"></script>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link href="reviews.css" rel="stylesheet" type="text/css">

    <?php
    require "templates/header_cdn.php"
    ?>
    <title>Book</title>
    <style>
        .col
        {
            text-align:left;
            border-style:initial;
        }

        .image
        {
            width:350px;
            margin-left:80px;
            /* -webkit-transform: scale(1);
            transform: scale(1);
            -webkit-transition: .3s ease-in-out;
            transition: .3s ease-in-out; */
        }
     
        .bookdesc {
          margin-top: 30px;
        }
        .btn2 {
          padding: 5px 50px 5px 35px;
          margin-left: 130px;
          background-color: #99ccff;
          color: white;
          cursor: pointer;
          border: 1px solid #99ccff;
          border-radius: 20px;
          border-bottom: 3px solid #99ccff;
          border-right: 3px solid #99ccff;
          border-top: 2px solid #99ccff;
        }

        .btn2:hover {
          background-color: white;
          color: #99ccff;
        }

        .btn2 i{
          position:absolute;

        }

        .btn2.active {
          background-color: #666;
          color: white;
        }
        .btn3 {
          padding: 5px 40px 5px 25px;
          background-color: white;
          color: #99ccff;
          cursor: pointer;
          border: 1px solid #99ccff;
          border-radius: 20px;
          border-bottom: 3px solid #99ccff;
          border-right: 3px solid #99ccff;
          border-top: 2px solid #99ccff;
        }

        .btn3:hover {
          background-color: #99ccff;
          color:white;
        }

        .btn3 i{
          position:absolute;

        }

        .btn3.active {
          background-color: #666;
          color: white;
        }

    </style>
  </head>

  <body>
  <?php

  require "templates/authenticated_author_header.php"
  ?>


   <div class="container" >
  <div class="bookcontent row">
    <div class="bookimg col-sm-5">
    <?php


    require "connection/connection.php";

    $bookID = $_GET['id'];


    $sql = "SELECT book.*, category.* ,author.* FROM book JOIN category USING (CategoryID) JOIN author USING (AuthorID) WHERE BookID = '$bookID '";
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {

        echo '<img class = "image" src="data:image/png;base64,'.base64_encode($row['ImageCover']).'"/>';



    ?>
    </div>
    <div class="col-sm-1">
    </div>
    <div class="bookdesc col-sm-6" style = "text-align:left;">
      <?php
          echo "<h4>".strtoupper($row['BookTitle'])."</h4>";
          echo "<h6 style='color:grey; font-size:13px;'>by ".$row['AuthorName']."</h6>";
          echo "<h6 style='color:grey; font-size:15px;'>".$row['BookDescription']."</h6>"."<br>"."<br>";
      ?>
      <div class="bookinfo row">
        <div class="col">
          <?php
            echo "<h6>Book Title: &emsp;&emsp;&emsp;&nbsp;"."<span style='color:grey;'>".$row['BookTitle']."</span>"."</h6>";
            echo "<h6>Serial Number: &emsp;&nbsp;"."<span style='color:grey;'>".$row['SerialNumber']."</span>"."</h6>";
            echo "<h6>Slug: &emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&nbsp;"."<span style='color:grey;'>Book Title</span>"."</h6>";
          ?>
        </div>
        <div class="col">
          <?php
            echo "<h6>Category Name: "."<span style='color:grey;'>&emsp;&emsp;&emsp;".$row['CategoryName']."</span>"."</h6>";
            echo "<h6>Publisher Name: "."<span style='color:grey;'>&emsp;&emsp;&emsp;".$row['PublisherName']."</span>"."</h6>";
            echo "<h6>Published Date: "."<span style='color:grey;'>&emsp;&emsp;&emsp;&nbsp;".$row['PublishedDate']."</span>"."</h6>"."<br>"."<br>";
          ?>
        </div>
      </div>
      <div class="bookbtn row">
        <div class="col-sm-5">
        <?php
          echo "<button type='button' class='btn2' onclick = window.location.href='".$row['ResourceUrl']."'><span>Read</span><i class='fas fa-book-open' style='margin-top:6px; margin-left:5px; font-size:12px;'></i></button>&ensp;";
        ?>
        </div>

        <?php
         
        }
        ?>

      </div>
  </div>
  </div>



<br><br>
<div class="container" style = "margin-left:-70px;" >


		<div class="content home">
			<h2>Reader Reviews</h2>
			<p>All Comments and reviews from the readers</p>
            <div class="reviews"></div>
<script>
const reviews_page_id = <?php echo $_GET['id']?>;
fetch("reviews.php?page_id=" + reviews_page_id).then(response => response.text()).then(data => {
	document.querySelector(".reviews").innerHTML = data;
	document.querySelector(".reviews .write_review_btn").onclick = event => {
		event.preventDefault();
		document.querySelector(".reviews .write_review").style.display = 'block';
		document.querySelector(".reviews .write_review input[name='name']").focus();
	};
	document.querySelector(".reviews .write_review form").onsubmit = event => {
		event.preventDefault();
		fetch("reviews.php?page_id=" + reviews_page_id, {
			method: 'POST',
			body: new FormData(document.querySelector(".reviews .write_review form"))
		}).then(response => response.text()).then(data => {
			document.querySelector(".reviews .write_review").innerHTML = data;
		});
	};
});
</script>

</div>
<br><br>
<?php

require "templates/footer.php"
?>
  <?php
  require "templates/body_cdn.php";
  ?>

  </body>
</html>
