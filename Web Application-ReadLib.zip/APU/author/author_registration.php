<?php


if(isset($_POST['submit']))
{

    require "connection/connection.php";

    $username  = $_POST['username'];
    $password = $_POST['password'];
    $passconfirm = $_POST['password-confirmation'];
    $emailAdderess = $_POST['email'];
    $date = date("Y/m/d") ;

    $sql = "SELECT * FROM author WHERE Username='$username'";
    $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));

    if(mysqli_num_rows($result) > 0) {
       echo "<script>alert('Failed : The Username Is Already Exist')</script>";

    } else if($password != $passconfirm) {
       echo "<script>alert('Failed : The Confirmation Password Are Not Match')</script>";

    } else {
      $encryptedPassword = md5($password);
    $sql = "INSERT INTO author (Username, Password, EmailAddress, RegistrationDate) VALUES ('$username','$encryptedPassword','$emailAdderess','$date')";

    if (!mysqli_query($conn,$sql))
    {
        echo "<script>alert('Failed : Account Not Registered')</script>";
    }
    else
    {
        echo "<script>alert('Account Succesfully Registered !')
        window.location.href = 'author_login.php'
        </script>";
    }

  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
        require "templates/header_cdn.php";

        ?>
    <title>Author Registration</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
          font-size: 31px !important;
          font-family:montserrat;
          font-weight: bold;
      }

      .navbar{
          height: 90px;
      }

      .description{
          color: rgb(155, 153, 153);
      }

      #button-register{
          float: right;
      }

      body {
            opacity: 0;
            transition: opacity 3s;
        }
    </style>
  </head>
  <body onload="document.body.style.opacity='1'">

  <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class=" navbar-brand h1" href="../index.php" >ReadLib</a>
        </div>
    </nav>

    <!-- 2 Columns 1 Row Seperator Start-->
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
        <div class="row">
          <div class="col-sm-5">
            <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="images/carousel_image.jpg" class="d-block w-100" alt="Carousel Image">
        </div>
        <div class="carousel-item">
        <img src="images/carousel_image_third.jpg" class="d-block w-100" alt="Carousel Image">
        </div>
    </div>
    </div>
</div>

    <!-- Bootstrap Carousel Slider End-->
    <div class="col-sm-1">
    </div>
    <!-- Bootstrap User Registration Form Start-->

          <div class="col-sm-6">
            <form method="POST" name = "registration">
                <h1>Author Registration</h1>
                <p class= "description">Writing is an art and a craft that needs to be developed through deliberate practice and study over a long period of time.</p>
                <div class="mb-3">
                  <label for="username" class="form-label">Username</label>
                  <input type="text" class="form-control rounded-pill" id ="username" aria-describedby="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" class="form-control rounded-pill" name="password" maxlength="12" minlength="8" required>
                </div>

                <div class="mb-3">
                  <label for="password-confirmation" class="form-label">Password Confirmation</label>
                  <input type="password" id="password-confirmation " class="form-control rounded-pill" name="password-confirmation" maxlength="12" minlength="8" required>
              </div>

                <div class="mb-3">
                  <label for="email" class="form-label">Email Address</label>
                  <input type="email" class="form-control rounded-pill" name="email" id="email" required >
                </div>

                  <br>
                <button type="submit" name = "submit" id = "submit" class="btn btn-primary btn-lg rounded-pill float-right" id="button-register"  style=" padding: 10px 10px;
                font-size: 20px;
                border-radius: 10px;
                width:30%;">Register</button>
              </form>

          </div>
        </div>
      </div>



    <?php
        require "templates/footer.php";

      ?>
    <?php
        require "templates/body_cdn.php";

        ?>
  </body>
</html>
