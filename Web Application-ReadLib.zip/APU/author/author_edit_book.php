
<?php
require "connection/connection.php";

$id = $_GET['id'];

// $sql = mysqli_query($conn,"SELECT * FROM book where BookID='$id'");
// $data = mysqli_fetch_array($sql);

if(isset($_POST['update']))
{
    $bookTitle = $_POST['bookTitle'];
    $serialNumber = $_POST['serialNumber'];
    $bookDescription = $_POST['bookDescription'];
    $category = $_POST['bookCategory'];
    $publisherName = $_POST['publisherName'];
    $publishedDate = $_POST['publishedDate'];
    $sources = $_POST['sources'];
    
    if($_FILES['bookimage']['tmp_name']){

        $bookCover = $_FILES['bookimage']['tmp_name'];
        $img = addslashes(file_get_contents($bookCover));
        $edit = mysqli_query($conn,"UPDATE book SET SerialNumber='$serialNumber', BookTitle='$bookTitle',BookDescription='$bookDescription',PublisherName='$publisherName',PublishedDate='$publishedDate',ResourceUrl='$sources', ImageCover = '{$img}' ,CategoryID = '$category' WHERE BookID ='$id'");
    }else{

        $edit = mysqli_query($conn,"UPDATE book SET SerialNumber='$serialNumber', BookTitle='$bookTitle',BookDescription='$bookDescription',PublisherName='$publisherName',PublishedDate='$publishedDate',ResourceUrl='$sources',CategoryID = '$category' WHERE BookID ='$id'");
    }

    if($edit)
    {
        echo "<script>alert('Record Has Been Updated')
        window.location.href = 'author_publication.php'
        </script>";
    }
    else {
        echo "<script>alert('Updated Failed : Record Not Updated')</script>";
    }
}
$stmt = $conn->prepare("SELECT SerialNumber, BookTitle, BookDescription , PublisherName, PublishedDate, ResourceUrl , CategoryID, ImageCover FROM book WHERE BookID = '$id'");

$stmt->execute();
$stmt->bind_result($SerialNumber, $BookTitle, $BookDescription, $PublisherName, $PublisherDate, $ResourceUrl, $CategoryID , $ImageCover );
$stmt->fetch();
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
    <?php
        require "templates/header_cdn.php"
    ?>
</head>
<body>

    <?php
        require "templates/authenticated_author_header.php"
    ?>

<div class = "container">
        <form method = "POST"  enctype="multipart/form-data">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="bookTitleInput">Book Title</label>
                            <input type="text" class="form-control" id="bookTitleInput" aria-describedby="titleHelp" name = "bookTitle"  value = "<?=$BookTitle?>" >
                        </div>

                        <div class="form-group">
                            <label for="serialNumber">Serial Number</label>
                            <input type="text" class="form-control" id="serialNumberInput" name = "serialNumber"  value = "<?=$SerialNumber?>"  require>
                        </div>


                        <div class="form-group">
                            <label for="bookDescription">Book Description</label>
                            <input type="text" class="form-control" id="bookDescription" name = "bookDescription"  value = "<?=$BookDescription?>"  require>
                        </div>


                    <div class="form-group">
                        <label for="bookCategory">Book Category (Genre)</label>
                        <select multiple class="form-control" id="bookCategory"  name = "bookCategory"   require>
                        <?php

                     

                        $sql = "SELECT * FROM category";
                        $records = mysqli_query($conn, $sql);
                        foreach ($records as $records) {
                        // ? inline if else  (ternary logic)
                        // referenecs  https://davidwalsh.name/php-shorthand-if-else-ternary-operators
                        // if there are multiline logic, not suitable, use alternative below 
                       echo  $CategoryID ==$records["CategoryID"] ? '<option value="'.$records["CategoryID"].'"  selected >'.$records["CategoryName"].'</option>' :'<option value="'.$records["CategoryID"].'"   >'.$records["CategoryName"].'</option>';
                       
                        // alternative 
                        // if ($CategoryID==$records["CategoryID"]){
                        //     echo '<option value="'.$records["CategoryID"].'"  selected >'.$records["CategoryName"].'</option>';
                        // }else{
                        //     echo '<option value="'.$records["CategoryID"].'"   >'.$records["CategoryName"].'</option>';
                        // }
                            
                    
                        }
                        $conn->close()
                        ?>
                        </select>

                    </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="publisherName">Publisher Name</label>
                            <input type="text" class="form-control" id="publisherName" name = "publisherName" value = "<?=$PublisherName?>" require>
                        </div>

                        <div class="form-group">
                            <label for="publishedDate">Published Date</label>
                            <input type="date" class="form-control" id="publishedDate" name= "publishedDate" value = "<?=$PublisherDate?>" require>
                        </div>

                        <div class="form-group">
                            <label for="sources">Sources</label>
                            <input type="url" class="form-control" id="sources" name = "sources" value = "<?=$ResourceUrl?>" require>
                        </div>

                        <div class="form-group">
                            <label for="image">Cover Image (Current Image)</label>

                            <div><img class = "image" src="data:image/png;base64,<?=base64_encode($ImageCover)?>" width="100"/></div>
                            <br>
           
                            <input type="file" accept= "image/png" class="form-control" id="image" name = "bookimage"  require>
                        </div><br><br>
                        <button type="submit" class="btn btn-primary float-right" name = "update" >Update</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>

</body>
</html>
