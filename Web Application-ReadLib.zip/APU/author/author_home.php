<?php
  require "authentication/session_authentication.php"
  ?>
    
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php
    
    require "templates/header_cdn.php"
    ?>
    <title>Home @<?=$_SESSION['username']?></title>
  
  </head>
  
  <body>

    

  <?php
  
  require "templates/authenticated_author_header.php"
  ?>
    
    <!-- 2 Columns 1 Row Seperator Start--> 
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
      <div class="row">
        <div class="col-sm-5">
          <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
      <div class="carousel-item active">
      <img src="images/carousel_image.jpg" class="d-block w-100" alt="Carousel Image">
      </div>
  </div>
  </div>
</div>

  <!-- Bootstrap Carousel Slider End-->
  <div class="col-sm-1">
  </div>
  <!-- Bootstrap User Registration Form Start-->
    
        <div class="col-sm-6">
              <h1>Welcome @<?=$_SESSION['username']?></h1><br>
              <p>ReadLib is an online public library portal that offers free and open-source publications. Beautiful and user-friendly web experience that makes reading and publications enjoyable! We deliver the best e-book service in the world, without regard to time or location. We hope you have a pleasant experience while using the services! </p>
              <div class="d-grid col-6" style="margin-left:-25px;">
                <button class="btn btn-primary rounded-pill" style="font-size: large;" type="button" onclick="window.location.href='author_library.php'"> Library</button>
              </div>
        </div>
      </div>
    </div>

  <!-- Bootstrap User Registration Form End-->
  <!-- 2 Columns 1 Row Seperator End-->
  <br><br><br><br>

    <div class="container" style="text-align: center;" >
    <h1>Notability</h1><br>
    <p>We strive to deliver the finest experience and services for our valued customers, thus below are some of the system's features.</p>
    </div>
    <div class="container px-1 py-5" id="custom-cards">
        <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-5 py-3">
          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/card.gif);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-10 lh-1.5 fw-bold">Any Where, Any Time</h2>
              </div>
            </div>
          </div>
    
          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/carousel_image_third.jpg);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-8 lh-1.5 fw-bold">Every Publication You Need</h2>
              </div>
            </div>
          </div>
    
          <div class="col" style="height: 500px;">
            <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url(images/card2.jpg);">
              <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                <h2 class="pt-100 mt-5 mb-2 display-8 lh-1.5 fw-bold">Every Moment You Feel </h2>
              </div>
            </div>
          </div>
  </div>
    <br><br><br><br>
    
    <!-- 2 Columns 1 Row Seperator Start--> 
    <!-- Bootstrap Carousel Slider Start-->
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <h1>Author's Publication</h1><br>
          <p>Writing is an art and a craft that needs to be developed through deliberate practice and study over a long period of time.</p>
          <div class="d-grid col-6" style="margin-left:-25px;">
            <button class="btn btn-primary rounded-pill" style="font-size: large;" type="button" onclick="window.location.href='author_update_book_form.php'">Publish</button>
          </div>
    </div>
  <!-- Bootstrap Carousel Slider End-->
  <div class="col-sm-1">
  </div>
  <!-- Bootstrap User Registration Form Start-->
    
  <div class="col-sm-5">
    <div id="carousel-control" class="carousel slide" data-bs-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<img src="images/feature.gif" class="d-block w-100" alt="Carousel Image">
</div>
</div>
</div>
</div>
</div>
</div>
  <!-- Bootstrap User Registration Form End-->
  <!-- 2 Columns 1 Row Seperator End-->


  <?php
  
  require "templates/footer.php"
  ?>
    
  <?php
  
  require "templates/body_cdn.php"
  ?>
    
  </body>
</html>