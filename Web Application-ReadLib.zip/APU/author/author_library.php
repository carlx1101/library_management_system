<?php
require "authentication/session_authentication.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/378db2667c.js" crossorigin="anonymous"></script>
  <title>Library</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Questrial&display=Bebas+Neue&family=Vollkorn&display=Patrick+Hand&display=swap" rel="stylesheet">
  <?php
      require "templates/header_cdn.php"
  ?>

<style>
* {
  box-sizing: border-box;
}

body {

  font-family: Arial;
}



h1 {
  font-size: 50px;
  text-align: center;
  font-family: 'Bebas Neue', cursive;
}

.row {
  margin: 10px -16px;
}

.row, .row > .column {
  padding: 20px;
}

.column {
  float: left;
  width: 33.33%;
  display: none;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

.row img {
  border-radius:8px;

}

.content {
  border: 2px solid #f2f2ff;
  width:320px;
  background-color:  #fafaff;
  padding: 10px;
  box-shadow: 0;
  position: relative;
  overflow: hidden;
  transform: scale(0.95);
  transition: box-shadow 0.5s, transform 0.5s;
  text-align:center;
  border-radius:15px;
}

.content:hover {
  transform:scale(1);
  box-shadow:5px 20px 30px rgba(0, 0, 0, 0.1);
}

.show {
  display: block;
}

.btn1 {
  border: none;
  outline: none;
  padding: 6px 10px;
  color: #5589D5;
  background-color:white;
  cursor: pointer;
  font-family: 'Questrial', sans-serif;
  font-size: 17px;
}

.btn1:hover {
  background-color: #b8c9ff;
  border-radius: 50px;
}

.btn1.active {
  background-color: #b8c9ff;
  color: white;
  border-radius: 50px;
}

.btn2 {
  padding: 5px 35px;
  background-color: white;
  color: #99ccff;
  cursor: pointer;
  border: 1px solid #99ccff;
  border-radius: 5px;
  border-bottom: 3px solid #99ccff;
  border-right: 3px solid #99ccff;
  border-top: 2px solid #99ccff;
}

.btn2:hover {
  background-color: #99ccff;
  color:white;
}

.btn2 i{
  position:absolute;

}

.btn2.active {
  background-color: #666;
  color: white;
}

.searchbtn {
  background-color: white;
  border: none;
  position: absolute;
  border-top: 1.8px solid #5589D5;
  border-right: 1.8px solid #5589D5;
  border-bottom: 1.8px solid #5589D5;
  border-radius: 20px;

}

.row h4{
  font-family: 'Patrick Hand', cursive;
  text-align: center;
  height:50px;
}

.row p .desc{
  font-family: 'Vollkorn', serif;
  height:100px;
  text-align: justify;
}

.quote {
    color:grey;

}

</style>
</head>
<body>
  <?php
      require "templates/authenticated_author_header.php"
  ?>

<div class="container">
  <h1>Publications</h1>
  <hr>

  <div id='category'>
    <?php
    require "connection/connection.php" ;

    $sql = "SELECT CategoryName FROM category";
    $records = mysqli_query($conn, $sql);

    echo "<button class='btn1' onclick=filterSelection('all')>All</button>&ensp;";

    while($row = mysqli_fetch_array($records))
    {
      echo "<button class='btn1' onclick=filterSelection('".$row['CategoryName']."')>".$row['CategoryName']."</button>&ensp;";
    }
    ?>

    <form style="float:right; padding-top:10px;" method="post">
      <input type='text' placeholder='&emsp;Search' name="search" style="border:1.8px solid #5589D5; border-radius:20px; width:280px;">
      <button class="searchbtn" name="searchBtn" type="submit"><i class="fas fa-search" style = "color:#5589D5;"></i></button>
    </form>
  </div>

  <div class='row'>
    <?php
    require "connection/connection.php";

    $searchKey = "";

    if(isset($_POST['searchBtn'])){
    	$searchKey = $_POST['search'];
    }

    $sql = "SELECT * FROM book JOIN category ON book.CategoryID=category.CategoryID WHERE BookTitle LIKE '%$searchKey%' ORDER BY BookTitle";
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
      echo "<div class='column ".$row['CategoryName']."'>";
      echo "<div class='content'>";
      echo '<img class="image" width="230" height="210" alt="img" src="data:image/png;base64,'.base64_encode($row['ImageCover']).'"/>';
      echo "<br><br><br>";
      echo "<h4>".$row['BookTitle']."</h4><i class = 'quote'>".$row['PublisherName']."</i>";
      echo "<p class = 'desc'>".$row['BookDescription']."</p>";
      echo "<button type='button' class='btn2' onclick = window.location.href='author_book_review.php?id=".$row['BookID']."'><span>Read</span></button>";

      echo "</div>";
      echo "</div>";
    }
    ?>
  </div>
</div>

<script>
  
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) AddClass(x[i], "show");
  }
}

function AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);
    }
  }
  element.className = arr1.join(" ");
}

// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("category");
var btns = btnContainer.getElementsByClassName("btn1");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}

</script>

<?php

  require "templates/footer.php"
  ?>

  <?php

  require "templates/body_cdn.php"
  ?>

</body>
</html>
