

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publish Book</title>

    <?php
        require "templates/header_cdn.php"
    ?>

</head>
<body>

    <?php
        require "templates/authenticated_author_header.php"

    ?>


    <?php
        require "author_update_book.php"
    ?>

    <div class = "container">
        <form method = "POST" enctype="multipart/form-data">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="bookTitleInput">Book Title</label>
                            <input type="text" class="form-control" id="bookTitleInput" aria-describedby="titleHelp" name = "bookTitle"  placeholder = "Enter Book Title" require>
                        </div>

                        <div class="form-group">
                            <label for="serialNumber">Serial Number</label>
                            <input type="text" class="form-control" id="serialNumberInput" name = "serialNumber" placeholder = "Enter Book Serial" require>
                        </div>


                        <div class="form-group">
                            <label for="bookDescription">Book Description</label>
                            <input type="text" class="form-control" id="bookDescription" name = "bookDescription" placeholder = "Enter Book Description" require>
                        </div>


                    <div class="form-group">
                        <label for="bookCategory">Book Category (Genre)</label>
                        <select multiple class="form-control" id="bookCategory"  name = "bookCategory" require>
                        <?php

                        require "connection/connection.php";

                        $sql = "SELECT * FROM category";
                        $records = mysqli_query($conn, $sql);
                        foreach ($records as $records) {
                            echo '<option value="'.$records["CategoryID"].'">'.$records["CategoryName"].'</option>';

                        }

                        ?>
                        </select>

                    </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="publisherName">Publisher Name</label>
                            <input type="text" class="form-control" id="publisherName" name = "publisherName" placeholder = "Enter Publisher Name" require>
                        </div>

                        <div class="form-group">
                            <label for="publishedDate">Published Date</label>
                            <input type="date" class="form-control" id="publishedDate" name= "publishedDate" require>
                        </div>

                        <div class="form-group">
                            <label for="sources">Sources</label>
                            <input type="url" class="form-control" id="sources" name = "sources" placeholder = "Enter Resources URL " require>
                        </div>

                        <div class="form-group">
                            <label for="image">Cover Image</label>
                            <input type="file" accept= "image/png" class="form-control" id="image" name = "bookimage" require>
                        </div>


                        <button type="submit"  name = "submit" class="btn btn-primary float-right" require>Publish</button>
                    </div>

                </div>
            </div>
        </form>
    </div>


    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>
</body>
</html>
