
    <?php

require "authentication/session_authentication.php";
if(isset($_POST['submit']))
{

    require "connection/connection.php";

    $bookTitle = $_POST['bookTitle'];
    $serialNumber = $_POST['serialNumber'];
    $bookDescription = $_POST['bookDescription'];
    $publisherName = $_POST['publisherName'];
    $publishedDate = $_POST['publishedDate'];
    $sources = $_POST['sources'];
    $author = $_SESSION['AuthorID'];
    $category = $_POST['bookCategory'];

    $bookCover = $_FILES['bookimage']['tmp_name'];
    $img = addslashes(file_get_contents($bookCover));

    $sqlBook = "SELECT * FROM book WHERE BookTitle='$bookTitle'";
    $sqlNum = "SELECT * FROM book WHERE SerialNumber='$serialNumber'";
    $resultBook = mysqli_query($conn,$sqlBook) or die(mysqli_error($conn));
    $resultNum = mysqli_query($conn,$sqlNum) or die(mysqli_error($conn));

    if(mysqli_num_rows($resultBook) > 0) {
       echo "<script>alert('The BookTitle is already exist')</script>";

    } else if(mysqli_num_rows($resultNum) > 0) {
       echo "<script>alert('The SerialNumber is already exist')</script>";

    } else {

    $sql = "INSERT INTO book (SerialNumber, BookTitle, BookDescription, PublisherName, PublishedDate,ResourceUrl,ImageCover,AuthorID,CategoryID) VALUES ('$serialNumber','$bookTitle','$bookDescription','$publisherName','$publishedDate','$sources','{$img}','$author','$category')";

    if (!mysqli_query($conn,$sql))
    {
        echo "<script>alert('Failed : Record Not Added')</script>";
    }
    else
    {
        echo "<script>alert('Record Has Been Added')
        window.location.href = 'author_update_book_form.php'
        </script>";
    }
  }
}

?>
