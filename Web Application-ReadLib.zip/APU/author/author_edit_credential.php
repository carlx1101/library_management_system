<?php
require "connection/connection.php";

$id = $_GET['id'];

if(isset($_POST['update']))
{

    $username = $_POST['username'];
    $password = md5($_POST['password']);


    $edit = mysqli_query($conn,"UPDATE author SET Username = '$username', Password = '$password' WHERE AuthorID ='$id'");
   
    if($edit)
    {
        echo "<script>alert('Success : Credentials Has Been Updated ! Please Login Again!')
        window.location.href = 'author_login.php'
        </script>";
    }
    else {
        echo "<script>alert('Failed : Record Not Updated')</script>";
    }
}
$stmt = $conn->prepare("SELECT Username, Password FROM author WHERE AuthorID = '$id'");

$stmt->execute();
$stmt->bind_result($username, $password);
$stmt->fetch();
$stmt->close();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credentials Reset</title>

    <?php
        require "templates/header_cdn.php"
    ?>

</head>
<body>

    <?php
        require "templates/authenticated_author_header.php"

    ?>


<div class="container">
<form method = "POST" >

  <div class="row">
    <div class="col">
  
  <div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" id="username" aria-describedby="username" name= "username" value = "<?=$username?>">  
  </div>
  
    </div>
    <div class="col">

    <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name= "password" value = "<?=$password?>"  maxlength="12" minlength="8" >  
  </div>

  <br><br>
    <button type="submit" name = "update" class="btn btn-primary float-right">Submit</button>
    
    </form>
    </div>
  </div>
</div>

<div class="container">

</div>
    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>
</body>
</html>