<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['authenticated'])) {
	header('Location: author_login.php');
	exit;
}

require "connection/connection.php";
// We don't have the password or email info stored in sessions so instead we can get the results from the database.
$stmt = $conn->prepare('SELECT Password, EmailAddress, AuthorName , bio, PhoneNumber, RegistrationDate FROM author WHERE AuthorID = ?');

$stmt->bind_param('i', $_SESSION['AuthorID']);
$stmt->execute();
$stmt->bind_result($password, $email, $name, $bio, $phoneNumber, $registrationDate);
$stmt->fetch();
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@<?=$_SESSION['username']?></title>
    <?php
    require "templates/header_cdn.php"
    ?>

<style>  
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap');
      .navbar-brand{
          font-size: 31px !important;
          font-family:montserrat;
          font-weight: bold;
      }

      .navbar{
          height: 220px;
          padding-top: -50px;

      }

      .description{
          color: rgb(155, 153, 153);
      }

      .btn{
          margin-top: 5px;
      }

      .navbar-nav{
          font-weight: bold;
      }
      
      h1{
        font-weight: bold;
      }
      p{
        line-height: 31px;
      }

      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
          
        }
      }

      .form-control {
        width: 490px !important;
        height: 40px;
      }

      .map-container{
      overflow:hidden;
      padding-bottom:56.25%;
      position:relative;
      height:0;
      }
      .map-container iframe{
      left:0;
      top:0;
      height:100%;
      width:100%;
      position:absolute;
      }

      .jumbotron{
        opacity: 0.8;
      }
      
      .second-nav{
        padding-bottom:210px !important;


      }

      ion-icon {
      font-size: 20px;
      color: #68A5FE;
      }

      body {
  padding: 25px;
  background-color: white;
  color: black;

}




.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
    </style>
</head>
<body>
<?php
    require "templates/authenticated_author_header.php"
    ?>
<nav>
    <div class="container">
    

    <div class="d-flex align-items-start">
  <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">User Information</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Privacy & Security</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-data" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Backup & Data</button>
    <!-- <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-custom" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Personalization</button> -->

  </div>
  <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
      
<div class="container" style="margin-left:130px;">
    <p><b>Username : </b>@<?=$_SESSION['username']?> </p>
    <p><b>Bio :</b><?=$bio?></p>
    <p><b>Full Name :</b><?=$name?></p>
    <p><b>Email Address :</b><?=$email?></p>
    <p><b>Phone Number :</b><?=$phoneNumber?></p>
    <p><b>Registration Date : </b><?=$registrationDate?></p>

    <button type="button" class="btn btn-primary" onclick="window.location.href='author_edit_info.php?id=<?=$_SESSION['AuthorID']?>'" style="width:110px;">Edit</button>
    </div>

    </div>
    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">

    <br><br><p><b> Account Username : </b><?=$_SESSION['username']?></p>
    <p><b>Account Password  (Encrypted):</b> <?=$password?> </p>

    <button type="button" class="btn btn-primary" onclick="window.location.href='author_edit_credential.php?id=<?=$_SESSION['AuthorID']?>'" style="width:110px;">Edit</button>
    </div>

    </div>

    <div class="tab-pane fade" id="v-pills-data" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">
    
    <p><b> Account Information </b> <a href="profile_csv.php?id=<?=$_SESSION['AuthorID']?>">Download</a></p>
    <p><b> Published Book </b> <a href="publication_csv.php?id=<?=$_SESSION['AuthorID']?>">Download </a></p>
    </div>
    </div>
    
    <div class="tab-pane fade" id="v-pills-custom" role="tabpanel" aria-labelledby="v-pills-profile-tab">
    <div class="container" style="margin-left:130px;">
  
    <label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
</label>


    <!-- <script>
  function addDarkmodeWidget() {
    new Darkmode().showWidget();
  }
  window.addEventListener('load', addDarkmodeWidget);
</script> -->

    </div>
    </div>
  </div>
</div>
    </div>


    <?php
        require "templates/footer.php"
    ?>
    <?php
        require "templates/body_cdn.php"
    ?>
</body>
</html>

