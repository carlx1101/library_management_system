<?php
        session_start();
        require "connection/connection.php";

        if ($stmt = $conn->prepare('SELECT AuthorID, Password FROM author WHERE Username = ?')) {
            $stmt->bind_param('s', $_POST['username']);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($authorID, $authorPassword);
                $stmt->fetch();
                
                if (md5($_POST['password']) === $authorPassword) {
                  
                    session_regenerate_id();
                    $_SESSION['authenticated'] = TRUE;
                    $_SESSION['username'] = $_POST['username'];
                    $_SESSION['AuthorID'] = $authorID;

                    echo "<script>alert('Success : Login Success' )
                    window.location.href = 'author_home.php'
                    </script>";

                } else {
                    
     
                    echo "<script>alert('Failed : Incorret Username or Password')
                    window.location.href = 'author_login.php'
                    </script>";
                }
            } else {
    
                echo "<script>alert('Failed : Incorret Username or Password')
                window.location.href = 'author_login.php'
                </script>";
            }
            $stmt->close();
        }
        ?>
