<?php
  require "authentication/session_authentication.php"
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Publications</title>

    <?php
        require "templates/header_cdn.php"
    ?>

<style>
      .image
      {
        width:400px;
        height:200px;
      }
    </style>
</head>
<body>

    <?php
        require "templates/authenticated_author_header.php"
    ?>
<div class = "container">

   <table class="table">
  <thead>
    <tr>
      <th scope="col">Book Title</th>
      <th scope="col">Serial Number</th>
      <th scope="col">Book Description</th>
      <th scope="col">Book Category</th>
      <th scope="col">Publisher Name</th>
      <th scope="col">Publisher Date</th>
      <th scope="col">Digital Sources</th>
      <th scope="col">Cover Image</th>
      <th scope="col">Modify</th>
      <th scope="col">Delete</th>

    </tr>
  </thead>
  <tbody>
  <?php

    require "connection/connection.php";

    $id = $_SESSION['AuthorID'];
    $sql = "SELECT * from book JOIN category ON book.CategoryID=category.CategoryID WHERE authorID = '$id'";
    $records = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_array($records))
    {
        echo "<tr>";
        echo "<td>".$row['BookTitle']."</td>";
        echo "<td>".$row['SerialNumber']."</td>";
        echo "<td>".$row['BookDescription']."</td>";
        echo "<td>".$row['CategoryName']."</td>";
        echo "<td>".$row['PublisherName']."</td>";
        echo "<td>".$row['PublishedDate']."</td>";
        echo "<td>".$row['ResourceUrl']."</td>";
        echo '<td><img class = "image" src="data:image/png;base64,'.base64_encode($row['ImageCover']).'"/>'. '</td>';
        echo "<td><a href=author_edit_book.php?id=".$row['BookID']."><button type='button' class='btn btn-warning' >Edit</button></td>";
        echo "<td><a href=author_delete_book.php?id=".$row['BookID']."><button type='button' class='btn btn-danger' >Delete</button></td>";
    }
    ?>
  </tbody>
</table>
</div>

<div class="container">

  <div class="row">
    <div class="col text-center">
      <button class="btn btn-primary" value="Print Data" onClick="window.print()">Print All</button>
    </div>
  </div>
</div>
    <?php
        require "templates/footer.php"
    ?>

    <?php
        require "templates/body_cdn.php"
    ?>

</body>
</html>
